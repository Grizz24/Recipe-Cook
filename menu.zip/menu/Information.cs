﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace menu
{
    public class Information
    {
        public string Name { get; set; }

        public string Ingredients { get; set; }

        public string Steps { get; set; }

        public string Group { get; set; }

        public double Quantity { get; set; }

        public double Calories { get; set; }
    }
}
